MENU : 
<a href="form_create.php">ISI DATA</a>
<a href="read.php">TAMPIL DATA</a>
<a href="cari.php">PENCARIAN DATA</a>
<a href="daftar_kelas.php">DAFTAR KELAS</a>
<a href="form_kelas.php">INPUT KELAS</a>
<a href="logout.php">LOGOUT</a>
<hr/>