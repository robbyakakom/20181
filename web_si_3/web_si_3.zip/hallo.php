TUGAS:
- Intall XAMPP
	(apacheandfrieds.com)

- Hasil:
	1.Screen shoot tampilan proses install
	2.Jelaskan hasil tampilan proses install
	3.Tuliskan script
		<?php
			echo "1.nim : nama" ;
			echo "2.nim : nama" ;
			echo "3.nim : nama" ;
		?>
	4.Screen shoot hasil tampilan
	
dikerjakan secara kelompok (2 / 3 mhs)
