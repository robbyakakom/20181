<?php

$a = 10 ;
$b = 30 ;

$c = $a + $b ;

echo $c ;

?>