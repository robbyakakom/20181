<!DOCTYPE html>
<html>
	<head>
		<title>APP WEB</title>
	</head>
	<body>
		<h1>
			<?php echo "SELAMAT DATANG <hr/>" ; ?>
		</h1>
		<?php echo "SELAMAT DATANG <hr/>" ; ?>
	</body>
</html>
