<?php
//membuat koneksi
$koneksi = mysqli_connect("localhost","root","","akdm") ;
?>