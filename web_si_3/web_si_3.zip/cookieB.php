<?php
//penggunaan cookie
echo $_COOKIE["nama"] ;

setcookie("nama","Budi",time()-1000) ;
?>