<?php
	function garis() {
		
		echo "<br/>====================================<br/>" ;
		
	}
?>


<?php
	garis() ;
	echo "AKAKOM YOGYAKARTA" ;
	garis() ;	
?>








