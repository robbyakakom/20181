menu : <br/>
<a href="prog_5_1.php">prog_5_1.php</a> | 
<a href="prog_5_2.php">prog_5_2.php</a> | 
<a href="prog_5_3.php">prog_5_3.php</a> | 
<a href="prog_5_4.php">prog_5_4.php</a> | 
<hr/>