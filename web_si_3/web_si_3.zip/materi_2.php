Algoritma Pemrograman dengan PHP
--------------------------------

Input
Proses
Output

sequence/runtunan/urut
conditional/pengkodisian/percabangan/pemilihan
looping/iterasi/perulangan

variabel $nama
tipe data integer, float, string, boolean, null
jugling -> tipe data yang berubah tergantung nilai
operator (* / + - % ^ = == > < >= <= && ||)

