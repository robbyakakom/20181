<?php
//medefinisikan cookie
setcookie("nama","Budi") ;

?>