<!DOCTYPE html>
<html>
	<head>
		<title>APP WEB</title>
	</head>
	<body>
		<h1>
			<?php 
				//ini komentar
				/*
				keterangan 1
				keterangan 2				
				*/
				echo "SELAMAT DATANG <hr/>" ; 
			?>
		</h1>
		<?php // echo "SELAMAT DATANG <hr/>" ; ?>
	</body>
</html>
