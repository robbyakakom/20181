perulangan / iterasi / looping
------------------------------
penyataan program diulang selama kondisi tertentu

sintaks :
1)while
	...pernyataan acuan nilai awal 
	while(kondisi){
		... pernyataan program ....
		... pernyataan merubah nilai acuan
	}
	
2)do-while
	...pernyataan acuan nilai awal 
	do{
		... pernyataan program ....
		... pernyataan merubah nilai acuan
	} while(kondisi)
		
3)for
	for(insiasi; kondisi; kenaikan){
		... pernyataan program ....
	}
