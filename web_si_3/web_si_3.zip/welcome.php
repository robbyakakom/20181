<?php

$nama = "Budi Firmansyah" ;

$a = 5 ;
$b = 7 ;
$c = $a + $b ;

/* struktur kontrol
- sequence
- conditional (if, switch)
- interation (while, do-while, for)
*/

/*
fungsi
- built in / bawaan
- buatan

nama_fungsi(parameter, ..., parameter)

function nama_fungsi(parameter, ... ,parameter){
	
	......
	
}

DBMS : software 

macam-macam database : MySQL, Postgress, Oracle, MariaDB, SQL Server, Ms Access

bahasa database : SQL (Structure Query Language) : mengakses database relasional

MoggoDB

Kategori Bahasa Database
- DDL (Data Definition Language) : kelompok bahasa yang digunakan untuk mendefinisikan database 
syntak : create, alter, drop

- DML (Data Manipulation Language) : kelompok bahasa yang digunakan memanipulasi / mengolah isi database
syntak : insert, update, delete, select





*/
?>