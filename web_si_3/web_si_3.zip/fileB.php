<?php
session_start() ;

echo $_SESSION["nim"] ;

session_destroy() ;
?>