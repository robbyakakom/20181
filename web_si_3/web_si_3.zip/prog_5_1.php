<?php
include("menu.php") ;
//membuat angka urut 1 s/d 10
$x = 1 ; //acuan awal
while($x >= 10){ //kondisi
	echo "nilai " . $x . "<br/>" ; //pernyataan program
	$x = $x + 1 ; //merubah nilai acuan
}
?>