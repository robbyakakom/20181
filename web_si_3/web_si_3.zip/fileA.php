<?php
session_start() ;

$_SESSION["nim"] = "099999" ;


?>