<?php
echo "ini file pertama <br/>" ;
include("prog_6_1.php") ;

echo "ini file kedua <br/>" ;
include("prog_6_2.php") ;
?>