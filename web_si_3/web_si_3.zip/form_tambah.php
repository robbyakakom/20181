<h1>HITUNG BILANGAN</h1>
<form action="hasil_tambah.php" method="get">
	Bil A <input type="text" name="bil_1" /> <br/>
	Bil B <input type="text" name="bil_2" /> <hr/>
	<input type="submit" value="TAMBAH" />
</form>