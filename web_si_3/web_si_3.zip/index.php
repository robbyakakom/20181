<form action="logproses.php" method="post">
	<h1>LOGIN SISTEM</h1>
	USER <br/> 
	<input type="text" name="user" /> <br/>
	PASSWORD <br/> 
	<input type="password" name="password" /> <br/>
	<input type="submit" value="LOGIN" />
</form>