<h1>INPUT DATA MAHASISWA</h1>
<form action="tampil.php" method="post">
	NIM <br/> 
	<input type="text" name="nim" /> <br/>
	Nama <br/> 
	<input type="text" name="nama" /> <br/>
	Umur <br/> 
	<input type="text" name="umur" /> <br/>
	No.HP <br/> 
	<input type="text" name="no_hp" /> <br/>
	Tinggi <br/> 
	<input type="text" name="tinggi" /> <br/>
	Jenis Kelamin <br/> 
	<input type="text" name="jenis_kelamin" /> <hr/>
	<input type="submit" value="KIRIM" />
</form>

