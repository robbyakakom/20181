<?php
//aturan variabel :
//variabel case sensitif
//variabel diawali tanda $
//variabel tidak diawali dengan angka
//jika terpisah sepasi gunakan _ atau buat kecilBesar

$nim = "0987900"; //string
$NIM = "0987900"; //string
$nama = "BUDI"; //string
$umur = 20 ; //integer
$no_hp = "088876234234" //string
$tinggi = 1.71 ; //float
$jenis_kelamin = true ; //boolean

//camel sintax
$jenisKelamin = true;

?>