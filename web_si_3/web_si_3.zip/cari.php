<?php
	include("menu_mhs.php") ;
?>
<form action="read.php" method="post">
	<h1>PENCARIAN DATA</h1>
	Nama Mahasiswa <input type="text" name="cari_nama" /> <br/>
	<input type="submit" value="CARI" />
</form>