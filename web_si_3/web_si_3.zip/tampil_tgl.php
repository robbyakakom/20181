<?php
echo $_POST['h']." - ". $_POST['b']." - ".$_POST["t"] ;
?>