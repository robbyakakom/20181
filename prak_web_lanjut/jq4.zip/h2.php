<!DOCTYPE html>
<html>
	<head>
		<title>APP WEB</title>
		<style>
			.merah{
				background: red;
			}
		</style>
	</head>
	<body>
		<h1 class="merah" style="">Judul Aplikasi</h1>
		<p class="merah">
			ini paragraph ini paragraph ini paragraph ini paragraph 
		</p>
	</body>
</html>