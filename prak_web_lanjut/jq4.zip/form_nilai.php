<form name="formNilai">
	Matakuliah <br/>
	<input type="text" name="matakuliah" /> <br/>
	SKS <br/>
	<input type="text" name="sks" /> <br/>
	Nilai Huruf <br/>
	<input type="text" name="nilai_huruf" /> <br/>
	<input type="button" value="SIMPAN" onclick="proses()" />
</form>
