<!DOCTYPE html>
<html>
	<head>
		<title>APP WEB</title>
		<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
		<script src="bootstrap/js/jquery.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<meta charset="utf-8"> 
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
			div{
				border: thin solid black;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="col-sm-4">
					<img src="image/Hydrangeas.jpg" width="200" />
				</div>
				<div class="col-sm-8">
					JUDUL APLIKASI
				</div>
			</div>
			<div class="row">
				<div class="col-sm-3">
					sidebar kiri
				</div>
				<div class="col-sm-6">
					konten
				</div>
				<div class="col-sm-3">
					<ul>
						<li><a href="">Link</a></li>
						<li><a href="">Link</a></li>
						<li><a href="">Link</a></li>
						<li><a href="">Link</a></li>
						<li><a href="">Link</a></li>
					</ul>
				</div>
			</div>	
			<div class="row">
				FOOTER
			</div>
		</div>
	</body>
</html>