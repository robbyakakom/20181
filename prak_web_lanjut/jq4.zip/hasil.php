Total Nilai : output (angka)
Total SKS : output
IPK	  : output

<table border="1">
	<tr>
		<td>Matakuliah</td>
		<td>SKS</td>
		<td>Nilai</td>
	</tr>
	<tr>
		<td>...</td>
		<td>...</td>
		<td>...</td>
	</tr>
	<tr>
		<td>...</td>
		<td>...</td>
		<td>...</td>
	</tr>
</table>