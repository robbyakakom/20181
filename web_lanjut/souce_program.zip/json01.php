<!DOCTYPE html>
<html>
	<head>
		<title>APP WEB</title>
	</head>
	<body id="isi">
	
	</body>
</html>
		<script>
			
			//objek di javascript
			var mahasiswa = {
								nim : "0999",
								nama : "Marjuki",
								jurusan : "Sistem Informasi",
								angkatan : 2017
							} ;
			var dataJson = JSON.stringify(mahasiswa) ;
		
			document.write(dataJson) ;
			
		</script>
