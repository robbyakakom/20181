<!DOCTYPE html>
<html>
	<head>
		<title>APP WEB</title>
		<link rel="stylesheet" type="text/css" href="file.css" />
	</head>
	<body>
		<h1>INI HALAMAN LAIN</h1>
	</body>
</html>