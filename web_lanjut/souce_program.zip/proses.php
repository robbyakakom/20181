<?php
	echo $_POST['data'] ;
?>