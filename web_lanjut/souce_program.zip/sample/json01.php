<script>
	var myJson = '{"nim":"0001","nama":"Budi","umur":23}' ;
	var objek = JSON.parse(myJson) ;
	document.write("NIM : " + objek.nim + "<br/>") ;
	document.write("Nama : " + objek.nama + "<br/>") ;
</script>