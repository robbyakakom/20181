<?php
echo $_GET['nama'] ;
?>