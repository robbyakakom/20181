<?php
include ("header.php") ;
?>

			
				<h1 class="text-info bg-warning huruf text-uppercase">Lorem Ipsum Dolor Sit Amet</h1>
				 <img src="img/581.JPG" class="img-circle" alt="RCTI OK" width="200"> 
				<p>
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed condimentum ut mi at hendrerit. Sed orci nibh, congue et ex ut, sollicitudin vehicula purus. Morbi neque orci, feugiat eget eros non, ullamcorper ultrices nisi. Quisque volutpat vel tortor a volutpat. Donec quis elit elit. Aliquam rutrum tortor justo, molestie sagittis risus ultrices nec. Curabitur ornare finibus porttitor. Mauris a mi mattis, dictum risus nec, facilisis augue. Proin tincidunt odio in tempus consequat. 
				</p>
				<p>
					Aenean laoreet, dolor sed sagittis tincidunt, urna eros blandit massa, et lacinia ante erat id risus. Ut lacinia tincidunt leo non bibendum. Curabitur erat nulla, tristique id metus in, elementum pulvinar sapien. Pellentesque condimentum viverra gravida. Phasellus augue nunc, finibus consectetur fermentum sit amet, consectetur id arcu. Nam eget sem eu velit malesuada pharetra non vel ex. Nunc sagittis augue lacus, et euismod nibh pellentesque vel. Aenean ante augue, porttitor elementum dui eu, pulvinar gravida felis. Curabitur felis magna, ultrices a pellentesque sed, blandit eu quam. Nulla sed nisl vitae purus consequat malesuada. 
				</p>	
			</div>
			<div class="col-sm-3" style="background: lightyellow">
				<div class="dropdown">
					<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Menu
					<span class="caret"></span></button>
					<ul class="dropdown-menu">
					  <li><a href="#">akakom</a></li>
					  <li><a href="#">siakad</a></li>
					  <li><a href="#">facebook</a></li>
					</ul>
				 </div>
			</div>
		</div>
	</div>
  </body>
</html>
