<!DOCTYPE html>
<html>
	<head>
		<title>APP WEB</title>
	</head>
	<body id="isi">
	
	</body>
</html>
		<script>
			
			//objek di javascript
			var dataJson = '{"nim":"0999","nama":"Marjuki","jurusan":"Sistem Informasi","angkatan":2017}' ;
			var mahasiswa = JSON.parse(dataJson) ;
		
			document.write(mahasiswa.nama) ;
			
		</script>
