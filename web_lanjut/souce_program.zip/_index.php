<!DOCTYPE html>
<html>
	<head>
		<title>Judul Aplikasi</title>
		<link rel="stylesheet" type="text/css" href="file.css" />
	</head>
	<body>
		<h1>Judul Artikel</h1>
		<hr/>
		<p id="atur">
			ini adalah paragraph
		</p>
		<p class="lain">
			paragraph lain
		</p>
		<h2 class="lain" style="font-size:32px;">ini pke klass</h2>
	</body>
</html>